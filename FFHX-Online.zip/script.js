// script.js
console.log("FFHX ऑनलाइन साइट लोड हो गई है।");
